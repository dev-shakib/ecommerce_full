<?php

return [
    'import' => 'Importer',
];
