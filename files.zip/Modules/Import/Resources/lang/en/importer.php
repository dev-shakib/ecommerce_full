<?php

return [
    'importer' => 'Importer',
    'download_csv' => 'Download CSV',
    'import' => 'Import',
    'import_types' => [
        'product' => 'Product',
    ],
    'run' => 'Run',
];
