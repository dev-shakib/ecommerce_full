<?php

return [
    'attribute_set' => 'Attribute Set',
    'attribute_sets' => 'Attribute Sets',
    'table' => [
        'name' => 'Name',
    ],
    'tabs' => [
        'group' => [
            'attribute_set_information' => 'Attribute Set Information',
        ],
        'general' => 'General',
    ],
];
