<?php

return [
    'exchange_service_is_not_configured' => 'Currency rate exchange service is not configured.',
];
