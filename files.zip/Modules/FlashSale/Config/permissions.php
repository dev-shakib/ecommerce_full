<?php

return [
    'admin.flash_sales' => [
        'index' => 'flashsale::permissions.index',
        'create' => 'flashsale::permissions.create',
        'edit' => 'flashsale::permissions.edit',
        'destroy' => 'flashsale::permissions.destroy',
    ],
];
