<div class="row">
    <div class="col-md-8">
        {{ Form::text('campaign_name', trans('flashsale::attributes.campaign_name'), $errors, $flashSale, ['required' => true]) }}
    </div>
</div>
