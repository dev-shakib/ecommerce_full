<?php

return [
    'index' => 'Index Brand',
    'create' => 'Create Brand',
    'edit' => 'Edit Brand',
    'destroy' => 'Delete Brand',
];
